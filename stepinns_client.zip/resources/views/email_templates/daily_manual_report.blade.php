<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
               <h1>Daily Transaction Report of date: {{$date}}</h1>
                
        </div>
    </body>
</html>