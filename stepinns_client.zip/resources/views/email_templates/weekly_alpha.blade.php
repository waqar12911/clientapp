<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
         <div>
            <h1>
                Next Layer Technology Client App
            </h1>
        </div>
        <div>
            <h2>Automated Weekly Transactions Report – Week of {{$currentDate}}</h2>
        </div>
        <div>
             <h2>{{$merchant_name}} - {{$merchant_id}}</h2>
        </div>
    </body>
</html>
