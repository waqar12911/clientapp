<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
            <h1>
                Next Layer Technology Client App
            </h1>
        </div>
        <div>
              <h2>Custom Transaction Report – {{$weekStart}} to {{$weekEnd}}</h2>
        </div>
    </body>
</html>
