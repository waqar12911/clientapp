<p> Your Clientapp One time reset password code : <?php echo $verify_email_code; ?> </p>
