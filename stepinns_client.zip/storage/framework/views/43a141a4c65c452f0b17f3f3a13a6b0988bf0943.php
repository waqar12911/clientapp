<?php if(session($key ?? 'status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session($key ?? 'status')); ?>

    </div>
<?php endif; ?>


<?php if(session()->has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/merchantnode/clientapp/resources/views/alerts/success.blade.php ENDPATH**/ ?>