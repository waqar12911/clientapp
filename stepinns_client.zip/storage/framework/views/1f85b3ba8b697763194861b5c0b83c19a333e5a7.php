<?php $__env->startSection('content'); ?>


    <div class="set_form">
        <div class="card">

            <div class="card-header">
                <h5 class="title">Client Edit</h5>
            </div>
            <?php if(Session::has('message')): ?>
                <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('updateClient',[$data->id])); ?>" autocomplete="off">
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">MaxBoost Limit</label>
                            <input type="text" name="maxboost_limit" value="<?php echo e($data->maxboost_limit); ?>" class="form-control" id="inputEmail4" placeholder="limit">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Status</label>
                            <select  name="is_active" value="<?php echo e($data->is_active); ?>" class="form-control " style="background: #27293d; ">
                                <option value="<?php echo e($data->is_active); ?>" selected ><?php
                                        if($data->is_active == ''){
                                            $status='';
                                        }
                                        if($data->is_active == '1'){
                                            $status='Active';
                                        }
                                        if($data->is_active == '0'){
                                            $status='De-Active';
                                        }
                                        echo $status;
                                        ?></option>
                                        <option value="1">Active</option>
                                        <option value="0">De-Active</option>
                            </select>
                            
                            
                            <!--<input type="text" name="is_active" value="<?php echo e($data->is_active); ?>" class="form-control" id="inputPassword4">-->
                        </div>
                    </div>
                </div>
                <div class="card-footer pull-right">
                    <button type="submit" class="btn btn-fill btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/merchantnode/clientapp/resources/views/users/edit-client.blade.php ENDPATH**/ ?>