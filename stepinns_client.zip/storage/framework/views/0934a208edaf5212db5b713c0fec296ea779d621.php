

<?php $__env->startSection('content'); ?>
<style>

.sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i {
  line-height: 32px;
}
.custom_color , .sorting_1 , table.dataTable.stripe tbody tr.odd, table.dataTable.display tbody tr.odd {
    background: #27293d !important;
}
.dataTables_wrapper .dataTables_length select {
    color: #fff !important;
}
.dataTables_wrapper .dataTables_length, .dataTables_wrapper .dataTables_filter, .dataTables_wrapper .dataTables_info, .dataTables_wrapper .dataTables_processing, .dataTables_wrapper .dataTables_paginate {
    color: #fff !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
    color: #e7e4e4 !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button , .dataTables_wrapper .dataTables_filter input {
    color: #fff !important;
}
.card-body {
    overflow-y: hidden;
}
.form-control
{
    color: black !important;
}
</style>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
        </div>
<div class="col-md-12">
    <div class="card ">
        <div class="card-header">
            <div class="row">
                <div class="col-8">
                    <h4 class="card-title">Channels</h4>
                </div>
                <div class="col-4 text-right">
                  <a href="#" data-toggle="modal" data-target="#shockpay" class="btn btn-sm btn-primary">Add Channel</a>
               </div>
            </div>
        </div>
        <div class="card-body">

    <div class="">
        <table id="myTable" class="text-primary display table tablesorter">
            <thead class="text-primary">
            <tr><th scope="col">Alias</th>
                <th scope="col">Channel ID</th>
                <th scope="col">Creation Date</th>
                <th scope="col">Action</th>
            </tr></thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="custom_color" >
                    <td><?php echo e($datum->alias); ?></td>
                    <td><?php echo e($datum->channel_id); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($datum->created_at)->format('M-d-Y')); ?></td>

                    <td >
                        <a class="btn btn-sm btn-primary" href="#" data-toggle="modal" data-target="#abc<?php echo e($datum->id); ?>">Edit</a>
                        <a class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this ?');" href="<?php echo e(route('channelDelete',[$datum->id])); ?>">Delete</a>
                      

                    <div id="abc<?php echo e($datum->id); ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                           <div class="modal-content">
                                <div class="modal-body">
                                     <form action="<?php echo e(route('updatechannel',$datum->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="">Alias</label>
                                            <input type="text" class="form-control" value="<?php echo e($datum->alias); ?>" required="" name="alias">
                                        </div>
                                        <input type="submit" value="Update" class="btn btn-primary">
                                    </form>
                                </div>
                            </div>

                         </div>
                        </div>
                </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
</div>
        <div class="card-footer py-4">
            <nav class="d-flex justify-content-end" aria-label="...">

            </nav>
        </div>
    </div>
   </div>
  </div>
</div>


<div id="shockpay" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <!--<p>Some text in the modal.</p>-->
        <div class="modal_image">
            <form action="<?php echo e(route('createchannel')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Alias</label>
                    <input type="text" class="form-control" required="" name="alias">
                </div>
                <div class="form-group">
                    <label for="">Channel ID</label>
                    <input type="text" class="form-control" required="" name="channel_id">
                </div>
                <input type="submit" value="Save" class="btn btn-primary">
            </form>
        </div>
      </div>
    </div>

  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Channels'), 'pageSlug' => 'channel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stepinns_client\resources\views/channels.blade.php ENDPATH**/ ?>