<?php $__env->startSection('content'); ?>
<style>
nav.navbar.navbar-expand-lg.navbar-absolute.navbar-transparent.fixed-top{
        display: none;

}
.main-box{
    margin-top:55px;
}
</style>
    <!--<div class="col-md-10 text-center ml-auto mr-auto">-->
    <!--    <h3 class="mb-5">Log in to see how you can speed up your web development with out of the box CRUD for #User Management and more.</h3>-->
    <!--</div>-->
    <div class="col-lg-4 main-box col-md-6 ml-auto mr-auto">
        <form class="form" method="POST" action="<?php echo e(route('do_login')); ?>">
            <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($email); ?>" name="email" >
                <input type="hidden" value="<?php echo e($password); ?>" name="password" >
            <div class="card card-login card-white">
                <div class="card-header">
                   
                    <h1 style="padding-left:30px;padding-top: 30px;"><?php echo e(__('Verify Email Code')); ?></h1>
                </div>
                <div class="card-body">
                    <?php

                    echo $error;
                    ?>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <i class="tim-icons icon-lock-circle"></i>
                            </div>
                        </div>
                        <input type="text" placeholder="<?php echo e(__('Enter Email Code')); ?>" name="verify_email_code" class="form-control">
                        
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" href="" class="btn btn-primary btn-lg btn-block mb-3"><?php echo e(__('Verify')); ?></button>
                   
                    <div class="pull-right">
                        <h6>
                            <!--<a href="<?php echo e(route('password.request')); ?>" class="link footer-link"><?php echo e(__('Forgot password?')); ?></a>-->
                        </h6>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'login-page', 'page' => __('Login Page'), 'contentClass' => 'login-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/merchantnode/clientapp/resources/views/users/verify.blade.php ENDPATH**/ ?>