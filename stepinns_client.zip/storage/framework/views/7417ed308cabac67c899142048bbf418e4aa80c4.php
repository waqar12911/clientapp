<p> Your Nextlayer Two-Factor Sovereign Code : <?php echo $verify_email_code; ?> </p>
<?php /**PATH /var/www/html/merchantnode/clientapp/resources/views/emails/reset_password.blade.php ENDPATH**/ ?>