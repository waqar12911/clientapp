                               <table id="myTable" class="text-primary display table tablesorter  table-responsive">
                                <thead class="text-primary">
                                <tr>
                                   <th scope="col" style="white-space: nowrap; "><input type="checkbox" class="hideClient" name="all" id="checkall" />Check All</th>
                                    <th scope="col">label</th>
                                    <th scope="col">conversion rate</th>
                                    <th scope="col">BTC</th>
                                    <th scope="col">USD</th>
                                    <th scope="col">payment hash</th>
                                    <th scope="col">payment preimage</th>
                                    <th scope="col">status</th>
                                    <th scope="col">msatoshi</th>
                                    <th scope="col">destination</th>
                                    <th scope="col">Created at </th>
                                </tr></thead>
                                <tbody id="clientBody">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="custom_color" >
                                        <!--<td> <a href="javascriptvoid:(0)" data-toggle="modal" data-target="#checkModal" class=""> <input type="checkbox"> <?php echo e($datum->transaction_id); ?></a></td>-->
                                        <td><input type="checkbox" class="cb-element hideClient" name="dataEmail[]" value="<?php echo e($datum->id); ?>" /></td>
                                        <td><?php echo e($datum->transaction_label); ?></td>
                                        <td><?php echo e($datum->conversion_rate); ?></td>
                                        <td ><?php echo e($datum->transaction_amountBTC); ?></td>
                                        <td ><?php echo e($datum->transaction_amountUSD); ?></td>
                                        <td><div  class="style_prevu_kit"><?php echo QrCode::generate($datum->payment_hash);; ?></div></td>
                                        <td><div  class="style_prevu_kit"><?php echo QrCode::generate($datum->payment_preimage);; ?></div></td>
                                        <td><?php echo e($datum->status); ?></td>
                                        <td><?php echo e($datum->msatoshi); ?></td>
                                        <td><div  class="style_prevu_kit"><?php echo e($datum->destination); ?></div></td>
                                        <td><?php echo e($datum->transaction_timestamp); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table><?php /**PATH C:\xampp\htdocs\stepinns_client\resources\views/admin_settings/alpha-transection/_transactions.blade.php ENDPATH**/ ?>